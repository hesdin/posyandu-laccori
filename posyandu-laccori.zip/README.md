1.Run git clone <my-cool-project> <br>
2.Run composer install <br>
3.Run cp .env.example .env <br>
4.Run php artisan key:generate <br>
5.Run php artisan migrate <br>
6.Run php artisan serve <br>
7.Go to link localhost:8000 <br>
