

<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('content'); ?>
  <div class="container-fluid">
    <div class="row justify-content-center">
      <div class="col-12">
        <div class="row align-items-center mb-2">
          <div class="col">
            <h2 class="h5 page-title">Hi Admin!</h2>
          </div>
        </div>
        
        <div class="row">
          <div class="col-md-6 col-xl-4 mb-4">
            <div class="card shadow">
              <div class="card-body">
                <div class="row align-items-center">
                  <div class="col-3 text-center">
                    <span class="circle circle-sm bg-primary">
                      <i class="fe fe-16 fe-users text-white mb-0"></i>
                    </span>
                  </div>
                  <div class="col pr-0">
                    <p class="mb-0">Jumlah Keluarga</p>
                    <span class="h3 mb-0"><?php echo e($keluarga); ?></span>
                    
                  </div>
                </div>
              </div>
            </div>
          </div>

          <div class="col-md-6 col-xl-4 mb-4">
            <div class="card shadow">
              <div class="card-body">
                <div class="row align-items-center">
                  <div class="col-3 text-center">
                    <span class="circle circle-sm bg-primary">
                      <i class="fe fe-16 fe-user text-white mb-0"></i>
                    </span>
                  </div>
                  <div class="col pr-0">
                    <p class="mb-0">Jumlah Ibu Hamil</p>
                    <span class="h3 mb-0"><?php echo e($ibuHamil); ?></span>
                    
                  </div>
                </div>
              </div>
            </div>
          </div>

          <div class="col-md-6 col-xl-4 mb-4">
            <div class="card shadow">
              <div class="card-body">
                <div class="row align-items-center">
                  <div class="col-3 text-center">
                    <span class="circle circle-sm bg-primary">
                      <i class="fe fe-16 fe-user text-white mb-0"></i>
                    </span>
                  </div>
                  <div class="col pr-0">
                    <p class="mb-0">Jumlah Balita</p>
                    <span class="h3 mb-0"><?php echo e($balita); ?></span>
                    
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        
      </div>
    </div>
    
    


  </div>
  </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\edin\Documents\code\posyandu-laccori\resources\views/admin/pages/dashboard.blade.php ENDPATH**/ ?>