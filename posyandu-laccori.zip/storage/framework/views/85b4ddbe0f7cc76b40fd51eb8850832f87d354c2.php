

<?php $__env->startSection('title', 'Edit Data Posyandu'); ?>

<?php $__env->startPush('css'); ?>
  <link rel="stylesheet" href="<?php echo e(asset('assets/css/select2.css')); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
  <div class="container-fluid">
    <div class="row justify-content-center">
      <div class="col-12">
        <div class="row align-items-center">
          <div class="col">
            <h4 class="h4 mb-0 page-title">Edit Data Posyandu <?php echo e(Str::ucfirst($posyandu->balita->nama)); ?></h4>
          </div>
        </div>
        <div class="row my-4">
          <div class="col-md-6">
            <div class="card shadow">
              <div class="card-body">
                <form action="<?php echo e(route('admin.balita-posyandu.update', $posyandu->id)); ?>" method="post">
                  <?php echo method_field('PUT'); ?>
                  <?php echo csrf_field(); ?>
                  <div class="modal-body">
                    <div class="form-group mb-3">
                      <label for="tgl_posyandu">Tanggal Posyandu</label>
                      <input class="form-control" value="<?php echo e($posyandu->tgl_posyandu); ?>" id="tgl_posyandu" type="date"
                        name="tgl_posyandu" required>
                    </div>

                    <div class="form-group mb-3">
                      <label for="berat_badan">Berat Badan (Kg)</label>
                      <input type="number" name="berat_badan" class="form-control" value="<?php echo e($posyandu->berat_badan); ?>"
                        step="0.1" required>
                    </div>

                    <div class="form-group mb-3">
                      <label for="tinggi_badan">Tinggi Badan (Cm)</label>
                      <input type="number" value="<?php echo e($posyandu->tinggi_badan); ?>" name="tinggi_badan" class="form-control"
                        step="0.1" required>
                    </div>

                    <div class="form-group mb-3">
                      <label for="lingkar_kepala">Lingkar Kepala (Cm)</label>
                      <input type="number" value="<?php echo e($posyandu->lingkar_kepala); ?>" name="lingkar_kepala"
                        class="form-control" step="0.1" required>
                    </div>

                    <div class="form-group mb-3">
                      <label for="imunisasi">Imunisasi - Pemberian Vaksin </label>
                      <select class="form-control select2 select2-hidden-accessible" id="imunisasi"
                        data-select2-id="imunisasi" tabindex="-1" aria-hidden="true" name="imunisasi">
                        <?php $__currentLoopData = $d_imunisasi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $imunisasi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <option value="<?php echo e($imunisasi->id); ?>"
                            <?php echo e($posyandu->imunisasi_id === $imunisasi->id ? 'selected' : ''); ?>>
                            <?php echo e($imunisasi->nama); ?>

                          </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </select>
                    </div>

                  </div>
                  <div class="modal-footer">
                    <button type="button" class="btn mb-2 btn-secondary" data-dismiss="modal">Batal</button>
                    <button type="submit" class="btn mb-2 btn-primary">Ubah</button>
                  </div>
                </form>
              </div>
            </div> <!-- .col-12 -->
          </div> <!-- .row -->
        </div>
      </div>
    </div>
  </div>

  <?php $__env->startPush('script'); ?>
    <script src='<?php echo e(asset('assets/js/select2.min.js')); ?>'></script>
    <script>
      $('.select2').select2({
        theme: 'bootstrap4',
      });
      $('.select2-multi').select2({
        multiple: true,
        theme: 'bootstrap4',
      });
    </script>
  <?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\edin\Documents\code\posyandu-laccori\resources\views/admin/pages/balita-posyandu-edit.blade.php ENDPATH**/ ?>