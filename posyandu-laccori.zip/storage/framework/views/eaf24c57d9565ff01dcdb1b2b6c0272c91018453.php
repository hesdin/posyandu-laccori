<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <title>Laporan Pemeriksaan Ibu Hamil</title>
  <style>
    * {
      font-family: Arial, Helvetica, sans-serif;
      font-size: 12px;
      margin: 0px;
    }

    #kop {
      margin-top: 40px;
      text-align: center;
    }

    h1 {
      font-size: 14px;

    }

    #table {
      margin-top: 20px;
      margin-left: 40px;
      margin-right: 40px;

    }

    #ttd {
      margin-top: 40px;
      margin-left: 40px;
      margin-right: 40px;

      float: right;
    }

    .nama {
      margin-top: 45px;
      text-decoration: underline;
      font-weight: bold;
    }

    table {
      width: 100%;
    }

    table,
    th,
    td {
      border: 1px solid black;
      border-collapse: collapse;
    }
  </style>
</head>

<body>
  <section id="kop">
    <h1>Laporan Balita Posyandu Desa Laccorri</h1>
    <h1>Kecamatan Dua Boccoe</h1>
    <p>Januari 2022</p>
  </section>

  <section id="table">
    <table>
      <thead>
        <tr>
          <th rowspan="2">No</th>
          <th rowspan="2">Nama Ibu Hamil</th>
          <th rowspan="2">Nama Suami</th>
          <th rowspan="2">Tgl Lahir</th>
          <th rowspan="2">Anak Ke - </th>
          <th rowspan="2">Usia Kehamilan </th>
          <th colspan="6">Hasil Pemeriksaan</th>
        </tr>

        <tr>
          <th>Tekanan Darah</th>
          <th>Berat Badan</th>
          <th>Tinggi Fundus</th>
          <th>Letak Janin</th>
          <th>Kaki Bengkak</th>
          <th>Tindakan</th>
        </tr>
      </thead>
      <tbody>

        <?php $__currentLoopData = $d_pemeriksaan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pemeriksaan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <tr style="text-align: center">
            <td><?php echo e($loop->iteration); ?></td>
            <td><?php echo e($pemeriksaan->ibuHamil->nama); ?></td>
            <td><?php echo e($pemeriksaan->ibuHamil->user->nama); ?></td>
            <td><?php echo e($pemeriksaan->ibuHamil->tgl_lahir); ?></td>
            <td><?php echo e($pemeriksaan->ibuHamil->anak_ke); ?></td>
            <td><?php echo e($pemeriksaan->umur_kehamilan); ?> Minggu</td>
            <td><?php echo e($pemeriksaan->tekanan_darah); ?></td>
            <td><?php echo e($pemeriksaan->berat_badan); ?> Kg</td>
            <td><?php echo e($pemeriksaan->tinggi_fundus); ?></td>
            <td><?php echo e($pemeriksaan->letak_janin); ?></td>
            <td><?php echo e($pemeriksaan->kaki_bengkak); ?></td>
            <td><?php echo e($pemeriksaan->tindakan); ?></td>
          </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

      </tbody>
    </table>
  </section>

  <section id="ttd">
    <p>Laccorri, <?php echo e(\Carbon\Carbon::now()->isoFormat('D MMMM Y')); ?></p>
    <p>Kepala Posyandu</p>
    <p class="nama">Kepala Posyandu</p>
    <p>NIP.1231231231231</p>
  </section>

</body>

</html>
<?php /**PATH C:\Users\edin\Documents\code\posyandu-laccori\resources\views/laporan/ibu-hamil-pdf.blade.php ENDPATH**/ ?>