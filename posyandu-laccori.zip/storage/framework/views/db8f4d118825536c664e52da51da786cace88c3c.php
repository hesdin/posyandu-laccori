<!doctype html>
<html lang="en">
<?php echo $__env->make('admin.includes.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<body class="vertical  light  ">
  <div class="wrapper">
    <?php if(Auth::guard('web')): ?>
      
      <?php echo $__env->make('user.includes.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      
    <?php endif; ?>

    
    <?php echo $__env->make('user.includes.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    
    <main role="main" class="main-content">
      
      <?php echo $__env->yieldContent('content'); ?>
      
    </main> <!-- main -->
  </div> <!-- .wrapper -->
  
  <?php echo $__env->make('admin.includes.script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  
</body>

</html>
<?php /**PATH C:\Users\edin\Documents\code\posyandu-laccori\resources\views/user/app.blade.php ENDPATH**/ ?>