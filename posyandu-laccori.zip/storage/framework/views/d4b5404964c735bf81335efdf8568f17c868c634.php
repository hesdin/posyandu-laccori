

<?php $__env->startSection('title', 'Profile'); ?>

<?php $__env->startSection('content'); ?>
  <?php if(session()->has('success')): ?>
    <div class="alert alert-success alert-dismissible fade show" role="alert">
      <strong></strong> <?php echo e(session()->get('success')); ?> <button type="button" class="close" data-dismiss="alert"
        aria-label="Close">
        <span aria-hidden="true">×</span>
      </button>
    </div>
  <?php endif; ?>

  <?php if(session()->has('error')): ?>
    <div class="alert alert-danger alert-dismissible fade show" role="alert">
      <strong></strong> <?php echo e(session()->get('error')); ?> <button type="button" class="close" data-dismiss="alert"
        aria-label="Close">
        <span aria-hidden="true">×</span>
      </button>
    </div>
  <?php endif; ?>
  <div class="row">

    <div class="col-md-6">

      <div class="card shadow mb-4">
        <form action="<?php echo e(route('profile.update', auth()->user()->id)); ?>" method="post">
          <?php echo csrf_field(); ?>
          <?php echo method_field('PATCH'); ?>
          <div class="card-body">

            <p class="mb-3"><strong>Profile</strong></p>

            <div class="form-group mb-3">
              <label for="simpleinput">Nomor Kartu Keluarga</label>
              <input type="text" id="simpleinput" class="form-control" value="<?php echo e(auth()->user()->no_kk); ?>" readonly>
            </div>

            <div class="form-group mb-3">
              <label for="simpleinput">Kepala Keluarga</label>
              <input type="text" id="simpleinput" class="form-control" value="<?php echo e(auth()->user()->nama); ?>" readonly>
            </div>

            <?php if(auth()->user()->ibuHamil()->exists()): ?>
              <div class="form-group mb-3">
                <label for="simpleinput">Nama Istri</label>
                <input type="text" id="simpleinput" class="form-control" value="<?php echo e(auth()->user()->ibuHamil->nama); ?>"
                  readonly>
              </div>
            <?php endif; ?>

            <?php if(auth()->user()->balita()->exists()): ?>
              <div class="form-group mb-3">
                <label for="simpleinput">Balita</label>
                <input type="text" id="simpleinput" class="form-control" value="<?php echo e(auth()->user()->balita->nama); ?>"
                  readonly>
              </div>
            <?php endif; ?>
            <div class="form-group mb-3">
              <label for="example-textarea">Alamat</label>
              <textarea class="form-control" id="example-textarea" rows="2" readonly><?php echo e(auth()->user()->alamat); ?>

                      </textarea>
            </div>
          </div>
        </form>
      </div>

    </div>

    <div class="col-md-6">
      <div class="card shadow mb-4">
        <form action="<?php echo e(route('profile.update', auth()->user()->id)); ?>" method="post">
          <?php echo csrf_field(); ?>
          <?php echo method_field('PATCH'); ?>
          <div class="card-body">
            <p class="mb-3"><strong>Ganti Password</strong></p>

            <div class="form-group mb-3">
              <label for="pass">Password Lama</label>
              <input type="password" id="pass" name="pass" class="form-control">
            </div>

            <div class="form-group mb-3">
              <label for="new_pass">Password Baru</label>
              <input type="password" id="new_pass" name="new_pass" class="form-control">
              <p class="text-danger font-italic">*Kosongkan jika tidak merubah password</p>
            </div>

          </div>

          <div class="modal-footer">
            <button type="submit" class="btn mb-2 btn-primary">Ubah Password</button>
          </div>
        </form>
      </div>

    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('user.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\edin\Documents\code\posyandu-laccori\resources\views/user/pages/profile.blade.php ENDPATH**/ ?>