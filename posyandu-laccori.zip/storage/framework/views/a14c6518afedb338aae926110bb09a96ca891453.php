<!doctype html>
<html lang="en">
<?php echo $__env->make('admin.includes.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<body class="vertical  light  ">
    <div class="wrapper">
        
        <?php echo $__env->make('admin.includes.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        

        <?php if(auth()->guard('admin')): ?>
            
            <?php echo $__env->make('admin.includes.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            
        <?php endif; ?>

        <main role="main" class="main-content">
            
            <?php echo $__env->yieldContent('content'); ?>
            
        </main> <!-- main -->
    </div> <!-- .wrapper -->
    
    <?php echo $__env->make('admin.includes.script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    
</body>

</html>
<?php /**PATH C:\Users\edin\Documents\code\posyandu-laccori\resources\views/admin/layouts/app.blade.php ENDPATH**/ ?>