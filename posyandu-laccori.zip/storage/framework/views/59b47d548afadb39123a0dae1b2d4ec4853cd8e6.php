

<?php $__env->startSection('title', 'Imunisasi'); ?>

<?php $__env->startSection('content'); ?>
  <div class="col-md-12 col-lg-9">
    <?php if(Session::has('success')): ?>
      <div class="alert alert-success alert-dismissible fade show" role="alert" id="alertM">
        <strong>Sukses!</strong> <?php echo e(session('success')); ?>.<button type="button" class="close" data-dismiss="alert"
          aria-label="Close">
          <span aria-hidden="true">×</span>
        </button>
      </div>
    <?php endif; ?>
    <div class="card shadow">
      <div class="card-header">
        <div class="row align-items-center">
          <div class="col">
            <h5 class="h5 mb-0 page-title">Data Vaksin Imunisasi</h5>
          </div>
          <div class="col-auto">
            <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#defaultModal"><span
                class="fe fe-plus fe-12 mr-2"></span>Tambah</button>
          </div>
        </div>

      </div>
      <div class="card-body my-n2">
        <table class="table table-striped table-hover table-borderless">
          <thead>
            <tr>
              <th>No</th>
              <th>Nama Vaksin</th>
              <th>Umur Pemberian Vaksin</th>
              <th>Action</th>
            </tr>
          </thead>
          <tbody>

            <?php $__empty_1 = true; $__currentLoopData = $d_imunisasi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $imunisasi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
              <tr>
                <td><?php echo e($loop->iteration); ?></td>
                <th scope="col"><?php echo e($imunisasi->nama); ?></th>
                <td><?php echo e($imunisasi->umur_pemberian); ?></td>
                <td>
                  <form action="<?php echo e(route('admin.imunisasi.destroy', $imunisasi->id)); ?>" method="POST"
                    id="form<?php echo e($imunisasi->id); ?>">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                    <button class="btn btn-link show_confirm" type="submit" data-name="<?php echo e($imunisasi->nama); ?>">
                      <span class="fe fe-trash fe-14 text-danger"></span>
                    </button>
                  </form>
                </td>
              </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <?php endif; ?>


          </tbody>
        </table>
      </div>
    </div>
  </div>

  
  <div class="modal fade" id="defaultModal" tabindex="-1" role="dialog" aria-labelledby="defaultModalLabel"
    aria-hidden="true">
    <div class="modal-dialog" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="defaultModalLabel">Tambah Data Keluarga</h5>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <form action="<?php echo e(route('admin.imunisasi.store')); ?>" method="post">
          <?php echo csrf_field(); ?>
          <div class="modal-body">
            <div class="form-group mb-3">
              <label for="nama">Nama Vaksin</label>
              <input type="text" name="nama" class="form-control" required>
            </div>
            <div class="form-group mb-3">
              <label for="umur_pemberian">Umur Pemberian Vaksin (Bulan)</label>
              <input type="text" name="umur_pemberian" class="form-control" required>
              <p class="font-italic">*Contoh : Usia 0-1 bulan</p>
            </div>
          </div>
          <div class="modal-footer">
            <button type="button" class="btn mb-2 btn-secondary" data-dismiss="modal">Batal</button>
            <button type="submit" class="btn mb-2 btn-primary">Tambah</button>
          </div>
        </form>

      </div>
    </div>
  </div>
  

  <?php $__env->startPush('script'); ?>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/2.1.0/sweetalert.min.js"></script>
    <script>
      $('.show_confirm').click(function(event) {

        let form = $(this).closest("form");
        let name = $(this).data("name");

        event.preventDefault();
        swal({
            title: `Apakah anda yakin hapus ${name} ?`,
            text: "Data yang dihapus tidak dapat dikembalikan!",
            icon: "warning",
            buttons: true,
            dangerMode: true,
          })
          .then((willDelete) => {
            if (willDelete) {
              form.submit();
            }
          });
      });

      $("#alertM").show().delay(2000).fadeOut();
    </script>
  <?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\edin\Documents\code\posyandu-laccori\resources\views/admin/pages/imunisasi.blade.php ENDPATH**/ ?>